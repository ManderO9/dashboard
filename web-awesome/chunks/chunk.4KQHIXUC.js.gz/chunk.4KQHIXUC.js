/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  o,
  require_react
} from "./chunk.XJOHOSCS.js";
import {
  WaRelativeTime
} from "./chunk.XN64OIYE.js";
import {
  __toESM
} from "./chunk.JHZRD2LV.js";

// src/react/relative-time/index.ts
var React = __toESM(require_react(), 1);
var tagName = "wa-relative-time";
var reactWrapper = o({
  tagName,
  elementClass: WaRelativeTime,
  react: React,
  events: {},
  displayName: "WaRelativeTime"
});
var relative_time_default = reactWrapper;

export {
  relative_time_default
};
