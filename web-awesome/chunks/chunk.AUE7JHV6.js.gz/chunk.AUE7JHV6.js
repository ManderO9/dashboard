/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  o,
  require_react
} from "./chunk.XJOHOSCS.js";
import {
  WaBreadcrumb
} from "./chunk.ZIHKH5SO.js";
import {
  __toESM
} from "./chunk.JHZRD2LV.js";

// src/react/breadcrumb/index.ts
var React = __toESM(require_react(), 1);
var tagName = "wa-breadcrumb";
var reactWrapper = o({
  tagName,
  elementClass: WaBreadcrumb,
  react: React,
  events: {},
  displayName: "WaBreadcrumb"
});
var breadcrumb_default = reactWrapper;

export {
  breadcrumb_default
};
