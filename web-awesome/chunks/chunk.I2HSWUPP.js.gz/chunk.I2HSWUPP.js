/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  o,
  require_react
} from "./chunk.XJOHOSCS.js";
import {
  WaFormatDate
} from "./chunk.KQATG76E.js";
import {
  __toESM
} from "./chunk.JHZRD2LV.js";

// src/react/format-date/index.ts
var React = __toESM(require_react(), 1);
var tagName = "wa-format-date";
var reactWrapper = o({
  tagName,
  elementClass: WaFormatDate,
  react: React,
  events: {},
  displayName: "WaFormatDate"
});
var format_date_default = reactWrapper;

export {
  format_date_default
};
