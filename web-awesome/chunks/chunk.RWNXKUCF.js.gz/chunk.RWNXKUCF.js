/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */

// src/internal/slot.ts
var HasSlotController = class {
  constructor(host, ...slotNames) {
    this.slotNames = [];
    this.handleSlotChange = (event) => {
      const slot = event.target;
      if (this.slotNames.includes("[default]") && !slot.name || slot.name && this.slotNames.includes(slot.name)) {
        this.host.requestUpdate();
      }
    };
    (this.host = host).addController(this);
    this.slotNames = slotNames;
  }
  hasDefaultSlot() {
    if (!this.host.childNodes) {
      return false;
    }
    return [...this.host.childNodes].some((node) => {
      if (node.nodeType === Node.TEXT_NODE && node.textContent.trim() !== "") {
        return true;
      }
      if (node.nodeType === Node.ELEMENT_NODE) {
        const el = node;
        const tagName = el.tagName.toLowerCase();
        if (tagName === "wa-visually-hidden") {
          return false;
        }
        if (!el.hasAttribute("slot")) {
          return true;
        }
      }
      return false;
    });
  }
  hasNamedSlot(name) {
    return this.host.querySelector?.(`:scope > [slot="${name}"]`) !== null;
  }
  /**
   * @param slotName     - Name of the slot to look for
   * @param propertyName - Generally we infer via `withHeader` property on the host, but in cases where its different, you can specify a manual property name.
   */
  test(slotName, propertyName) {
    if (propertyName && this.host.didSSR && !this.host.hasUpdated) {
      return Boolean(this.host[propertyName]);
    }
    return slotName === "[default]" ? this.hasDefaultSlot() : this.hasNamedSlot(slotName);
  }
  hostConnected() {
    const shadowRoot = this.host.shadowRoot;
    if (shadowRoot && "addEventListener" in shadowRoot) {
      shadowRoot.addEventListener("slotchange", this.handleSlotChange);
    }
  }
  hostDisconnected() {
    const shadowRoot = this.host.shadowRoot;
    if (shadowRoot && "removeEventListener" in shadowRoot) {
      shadowRoot.removeEventListener("slotchange", this.handleSlotChange);
    }
  }
};

export {
  HasSlotController
};
