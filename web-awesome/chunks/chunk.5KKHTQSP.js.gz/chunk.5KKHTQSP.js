/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  i
} from "./chunk.TLFIX76K.js";

// src/components/include/include.styles.ts
var include_styles_default = i`
  :host {
    display: block;
  }
`;

export {
  include_styles_default
};
