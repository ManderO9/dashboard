/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  select_styles_default
} from "../../chunks/chunk.WZ5J7J3M.js";
import "../../chunks/chunk.TLFIX76K.js";
import "../../chunks/chunk.BKE5EYM3.js";
import "../../chunks/chunk.JHZRD2LV.js";
export {
  select_styles_default as default
};
