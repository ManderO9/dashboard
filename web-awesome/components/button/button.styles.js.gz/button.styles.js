/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  button_styles_default
} from "../../chunks/chunk.TF6QZMKC.js";
import "../../chunks/chunk.TLFIX76K.js";
import "../../chunks/chunk.BKE5EYM3.js";
import "../../chunks/chunk.JHZRD2LV.js";
export {
  button_styles_default as default
};
