/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  breadcrumb_item_default
} from "../../chunks/chunk.QADVKO2M.js";
import "../../chunks/chunk.XJOHOSCS.js";
import "../../chunks/chunk.5MMXZB66.js";
import "../../chunks/chunk.D6GXWYLR.js";
import "../../chunks/chunk.3MSWQ3RG.js";
import "../../chunks/chunk.PZAN6FPN.js";
import "../../chunks/chunk.JGKQLB7S.js";
import "../../chunks/chunk.TLFIX76K.js";
import "../../chunks/chunk.BKE5EYM3.js";
import "../../chunks/chunk.JHZRD2LV.js";
export {
  breadcrumb_item_default as default
};
