/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  WaStartEvent
} from "../chunks/chunk.BMO76VKZ.js";
import "../chunks/chunk.JHZRD2LV.js";
export {
  WaStartEvent
};
