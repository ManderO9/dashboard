/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  WaCancelEvent
} from "../chunks/chunk.ZT4OZS6F.js";
import "../chunks/chunk.JHZRD2LV.js";
export {
  WaCancelEvent
};
